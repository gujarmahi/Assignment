import java.util.*;
class MulEx
{
	public static void main(String args[])
	{
	int a;
	System.out.println("Enter number:");
	Scanner sc=new Scanner(System.in);
	a=sc.nextInt();
	for(int i=1;i<=10;i++)
	{
	int Res=a*i;
	System.out.println(a+"*"+i+"="+Res);
	}
	}
}	