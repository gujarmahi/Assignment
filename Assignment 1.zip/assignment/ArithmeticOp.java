import java.util.*;
class ArithmeticOp
{
	public static void main(String args[])
	{
	int i,j,a,s,m,mo;
	float d;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter two numbers:");
	i=sc.nextInt();
	j=sc.nextInt();
	a=i+j;
	System.out.println("Adiition: "+a);
	s=i-j;
	System.out.println("Subtraction:"+s);
	m=i*j;
	System.out.println("Multiplication: "+m);
	d=i/j;
	System.out.println("Division: "+d);
	mo=i%j;
	System.out.println("Reminder: "+mo);
	}
}