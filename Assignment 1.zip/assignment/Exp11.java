//import java.lang.math.*;
class Exp11
{
public static void main(String args[])
{
	double radius=7.5;
	double perimeter=2*3.14*radius;
	double area=3.14*radius*radius;
	System.out.println("Perimeter: "+perimeter);
	System.out.println("area: "+area);
}
}