class OperatorEx
{
public static void main(String args[])
{
int i,j,k,l;
i= -5 + 8 * 6;
j= (55+9) % 9;
k= 20 + -3*5 / 8;
l=5 + 15 / 3 * 2 - 8 % 3;
System.out.println(i);
System.out.println(j);
System.out.println(k);
System.out.println(l);
}
}