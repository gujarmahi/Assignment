
public class OperatorEx {
public static void main(String args[])
{
	int i,j,k,l;
	i=-5+8*6;
	System.out.println(i);
	j=(55+9)%9;
	System.out.println(j);
	k=20+-3*5/8;
	System.out.println(k);
	l=5+15/3*2-8%3;
	System.out.println(l);
}
}
