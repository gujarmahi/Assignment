import java.util.Scanner;
public class multiplication {
public static void main(String args[])
{
	Scanner s=new Scanner(System.in);
	System.out.println("enter two numbers");
	int i,j,k;
	i=s.nextInt();
	j=s.nextInt();
	k=i*j;
	System.out.println(k);
}
}
