class Div
{
	public static void main(String args[])
	{
	int i=50,j=3,k;
	k=i/j;
	System.out.println("Division: " +k);
	}
}