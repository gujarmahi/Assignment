import java.util.Scanner;
class InputEx
{
public static void main(String args[])
{
int i,j,k;
System.out.println("Enter two numbers: ");
Scanner sc=new Scanner(System.in);
i=sc.nextInt();
j=sc.nextInt();
System.out.println(i);
System.out.println(j);
k=i*j;
System.out.println("Multiplication: "+k);
}
}