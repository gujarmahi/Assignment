//module Addition {
//}
class Addition
{
	public static void main(String args[])
	{
		int i=10,j=20,k;
		k=i+j;
		system.out.println("addition {0}",k);
	}
}