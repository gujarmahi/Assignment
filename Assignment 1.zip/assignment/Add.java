class Add
{
public static void main(String args[])
{
	int i=74,j=36,k;
	k=i+j;
	System.out.println("Addition: " +k);
}
}